// js/areas.js
// Starter area list. Replace/add areas as your game grows.
const AREAS = [
  { name: "Area 1", id: "area1" },
  { name: "Area 2", id: "area2" },
  { name: "Area 3", id: "area3" }
];

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("areas-container");
  if (!container) return;

  AREAS.forEach(area => {
    const button = document.createElement("button");
    button.textContent = area.name;
    button.dataset.area = area.id;
    button.addEventListener("click", () => {
      window.dispatchEvent(new CustomEvent("crzy-area-selected", {
        detail: area
      }));
    });
    container.appendChild(button);
  });
});
