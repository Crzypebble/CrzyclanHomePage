// js/main.js
document.addEventListener("DOMContentLoaded", () => {
  const sections = document.querySelectorAll(".menu-section");

  function showSection(id) {
    sections.forEach(section => {
      section.style.display = section.id === id ? "block" : "none";
    });
  }

  document.addEventListener("click", e => {
    const tab = e.target.closest(".menu-tab");
    if (!tab) return;

    const target = tab.dataset.target;
    if (target) showSection(target);
  });

  showSection("main-menu");
});
