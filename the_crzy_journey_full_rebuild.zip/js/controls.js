// js/controls.js
// Complete controls system:
// - PC keyboard bindings
// - Gamepad bindings
// - Click grey binding boxes to select a binding
// - One Rebind/Confirm button per row
// - Mobile touch preview
// - Drag, resize, save, reset mobile controls
// - Mobile game controls are hidden unless the game explicitly calls showTouchControls()

const DEFAULT_BINDINGS = {
  moveLeft: "ArrowLeft",
  moveRight: "ArrowRight",
  moveUp: "ArrowUp",
  moveDown: "ArrowDown",
  jump: "Space",
  attack: "KeyZ",
  pause: "Escape"
};

const DEFAULT_TOUCH_LAYOUT = {
  Left:   { xPct: 8,  yPct: 78, size: 80, action: "moveLeft" },
  Right:  { xPct: 20, yPct: 78, size: 80, action: "moveRight" },
  Up:     { xPct: 14, yPct: 66, size: 70, action: "moveUp" },
  Down:   { xPct: 14, yPct: 90, size: 70, action: "moveDown" },
  Jump:   { xPct: 82, yPct: 78, size: 90, action: "jump" },
  Attack: { xPct: 70, yPct: 85, size: 85, action: "attack" },
  Pause:  { xPct: 92, yPct: 6,  size: 60, action: "pause" }
};

let bindings = loadJSON("bindings", DEFAULT_BINDINGS);
let touchLayout = loadJSON("touchLayout", DEFAULT_TOUCH_LAYOUT);

const controlsList = document.getElementById("controls-list");
const controllerStatus = document.getElementById("controller-status");
const previewFrame = document.getElementById("controls-preview");
const btnEditTouch = document.getElementById("toggle-edit-touch");
const btnSaveTouch = document.getElementById("save-touch-layout");
const btnResetTouch = document.getElementById("reset-touch-layout");
const touchSizeSlider = document.getElementById("touch-size");
const selectedTouchLabel = document.getElementById("selected-touch-label");
const liveTouchControls = document.getElementById("touch-controls");

let editingTouch = false;
let selectedBtn = null;
let pollingId = null;
let rebindAction = null;
let rebindValueEl = null;
let rebindButtonEl = null;
let rebindKeyboardHandler = null;
let rebindGamepadStates = new Map();

function loadJSON(key, fallback) {
  try {
    const saved = JSON.parse(localStorage.getItem(key));
    if (!saved) return structuredCloneSafe(fallback);
    return { ...structuredCloneSafe(fallback), ...saved };
  } catch (_) {
    return structuredCloneSafe(fallback);
  }
}

function structuredCloneSafe(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function saveBindings() {
  localStorage.setItem("bindings", JSON.stringify(bindings));
}

function saveTouchLayout() {
  localStorage.setItem("touchLayout", JSON.stringify(touchLayout));
}

function isMobileUA() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

function hasGamepad() {
  const gps = navigator.getGamepads ? Array.from(navigator.getGamepads()).filter(Boolean) : [];
  return gps.length > 0;
}

function prettyBinding(value) {
  const names = {
    ArrowLeft: "Left Arrow", ArrowRight: "Right Arrow",
    ArrowUp: "Up Arrow", ArrowDown: "Down Arrow",
    Space: "Space", Escape: "Escape",
    KeyZ: "Z", KeyX: "X", KeyA: "A", KeyS: "S",
    Enter: "Enter", ShiftLeft: "Left Shift", ShiftRight: "Right Shift",
    ControlLeft: "Left Ctrl", ControlRight: "Right Ctrl"
  };

  if (names[value]) return names[value];

  const match = /^GP(\d+):Button(\d+)$/.exec(value);
  if (match) return `Controller ${Number(match[1]) + 1} • Button ${Number(match[2]) + 1}`;

  return value;
}

function actionName(action) {
  return action
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, c => c.toUpperCase());
}

function updateControllerStatus() {
  if (controllerStatus) {
    controllerStatus.textContent =
      `Controller: ${hasGamepad() ? "Connected" : "Not Connected"}`;
  }
}

window.addEventListener("gamepadconnected", updateControllerStatus);
window.addEventListener("gamepaddisconnected", updateControllerStatus);

// ---------- PC / Controller binding UI ----------

function renderBindingsList() {
  if (!controlsList) return;

  // Never put binding controls into the mobile preview.
  controlsList.innerHTML = "";

  Object.entries(bindings).forEach(([action, key]) => {
    const row = document.createElement("div");
    row.className = "control-row";

    const label = document.createElement("div");
    label.className = "control-label";
    label.textContent = actionName(action);

    // Grey box is the actual binding selector.
    const value = document.createElement("div");
    value.className = "binding-value";
    value.textContent = prettyBinding(key);
    value.tabIndex = 0;
    value.setAttribute("role", "button");
    value.title = "Click here to select this binding";

    // Only one Rebind button exists per row.
    const btn = document.createElement("button");
    btn.className = "rebind-button";
    btn.textContent = "Rebind";
    btn.type = "button";

    value.addEventListener("click", () => startRebind(action, value, btn));
    value.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        startRebind(action, value, btn);
      }
    });

    btn.addEventListener("click", e => {
      e.preventDefault();
      startRebind(action, value, btn);
    });

    row.appendChild(label);
    row.appendChild(value);
    row.appendChild(btn);
    controlsList.appendChild(row);
  });
}

function startRebind(action, valueEl, btnEl) {
  if (rebindAction) return;

  rebindAction = action;
  rebindValueEl = valueEl;
  rebindButtonEl = btnEl;

  valueEl.textContent = "Press key / controller...";
  valueEl.style.background = "rgba(120, 0, 0, .75)";
  btnEl.textContent = "Cancel";
  btnEl.classList.add("confirm");

  rebindKeyboardHandler = e => {
    e.preventDefault();
    e.stopPropagation();

    // Escape cancels instead of binding Escape.
    if (e.code === "Escape") {
      finishRebind(false);
      return;
    }

    bindings[action] = e.code || e.key || "Unknown";
    finishRebind(true);
  };

  document.addEventListener("keydown", rebindKeyboardHandler, true);

  rebindGamepadStates.clear();

  const poll = () => {
    const gps = navigator.getGamepads
      ? Array.from(navigator.getGamepads()).filter(Boolean)
      : [];

    for (const gp of gps) {
      for (let i = 0; i < gp.buttons.length; i++) {
        const pressed = !!gp.buttons[i]?.pressed;
        const wasPressed = rebindGamepadStates.get(`${gp.index}:${i}`) || false;

        // Rising edge only, so a held controller button doesn't instantly
        // trigger repeated rebinding.
        if (pressed && !wasPressed) {
          bindings[action] = `GP${gp.index}:Button${i}`;
          finishRebind(true);
          return;
        }

        rebindGamepadStates.set(`${gp.index}:${i}`, pressed);
      }
    }

    pollingId = requestAnimationFrame(poll);
  };

  pollingId = requestAnimationFrame(poll);
}

function finishRebind(save) {
  if (!rebindAction) return;

  if (save) saveBindings();

  if (pollingId) {
    cancelAnimationFrame(pollingId);
    pollingId = null;
  }

  if (rebindKeyboardHandler) {
    document.removeEventListener("keydown", rebindKeyboardHandler, true);
    rebindKeyboardHandler = null;
  }

  rebindGamepadStates.clear();

  rebindAction = null;
  rebindValueEl = null;
  rebindButtonEl = null;

  renderBindingsList();
}

// ---------- Touch preview ----------

function showPreviewFrame(show) {
  if (!previewFrame) return;

  previewFrame.style.display = show ? "block" : "none";

  if (show) {
    renderTouchPreview();
  } else {
    previewFrame.innerHTML = "";
    selectedBtn = null;
    setSelectedLabel();
  }
}

function pctToPx(xPct, yPct) {
  const rect = previewFrame.getBoundingClientRect();
  return {
    x: (xPct / 100) * rect.width,
    y: (yPct / 100) * rect.height
  };
}

function pxToPct(xPx, yPx) {
  const rect = previewFrame.getBoundingClientRect();

  return {
    xPct: Math.max(0, Math.min(100, (xPx / rect.width) * 100)),
    yPct: Math.max(0, Math.min(100, (yPx / rect.height) * 100))
  };
}

function renderTouchPreview() {
  if (!previewFrame) return;

  previewFrame.innerHTML = "";

  const label = document.createElement("div");
  label.className = "preview-label";
  label.textContent = "Mobile controls preview — drag buttons or resize them";
  previewFrame.appendChild(label);

  Object.entries(touchLayout).forEach(([buttonLabel, cfg]) => {
    const pos = pctToPx(cfg.xPct, cfg.yPct);

    const btn = document.createElement("div");
    btn.className = "touch-preview-btn";
    btn.dataset.label = buttonLabel;
    btn.textContent = buttonLabel;

    btn.style.left = `${pos.x - cfg.size / 2}px`;
    btn.style.top = `${pos.y - cfg.size / 2}px`;
    btn.style.width = `${cfg.size}px`;
    btn.style.height = `${cfg.size}px`;
    btn.style.fontSize = `${Math.max(14, cfg.size * 0.28)}px`;

    const handle = document.createElement("div");
    handle.className = "resize-handle";
    handle.setAttribute("aria-label", "Resize");
    btn.appendChild(handle);

    btn.addEventListener("pointerdown", e => {
      if (e.target === handle) return;

      e.preventDefault();
      setSelected(btn);

      if (editingTouch) {
        startDrag(btn, e);
      }
    });

    handle.addEventListener("pointerdown", e => {
      e.stopPropagation();
      e.preventDefault();

      if (!editingTouch) return;
      setSelected(btn);
      startResize(btn, e);
    });

    previewFrame.appendChild(btn);
  });

  setSelected(null);
}

function setSelected(btn) {
  if (!previewFrame) return;

  previewFrame
    .querySelectorAll(".touch-preview-btn")
    .forEach(el => el.classList.remove("selected"));

  selectedBtn = btn;

  if (btn) {
    btn.classList.add("selected");
  }

  setSelectedLabel();
  syncSliderToSelection();
}

function setSelectedLabel() {
  if (!selectedTouchLabel) return;

  selectedTouchLabel.textContent =
    `Selected: ${selectedBtn ? selectedBtn.dataset.label : "None"}`;
}

function syncSliderToSelection() {
  if (!touchSizeSlider || !selectedBtn) return;

  const label = selectedBtn.dataset.label;

  if (touchLayout[label]) {
    touchSizeSlider.value = touchLayout[label].size;
  }
}

function startDrag(btn, e) {
  if (!previewFrame) return;

  btn.setPointerCapture?.(e.pointerId);

  const rect = btn.getBoundingClientRect();
  const frameRect = previewFrame.getBoundingClientRect();

  const offsetX = e.clientX - rect.left;
  const offsetY = e.clientY - rect.top;

  function move(ev) {
    const nx = ev.clientX - offsetX;
    const ny = ev.clientY - offsetY;

    const w = rect.width;
    const h = rect.height;

    const clampedX = Math.max(
      frameRect.left,
      Math.min(frameRect.right - w, nx)
    );

    const clampedY = Math.max(
      frameRect.top,
      Math.min(frameRect.bottom - h, ny)
    );

    btn.style.left = `${clampedX - frameRect.left}px`;
    btn.style.top = `${clampedY - frameRect.top}px`;
  }

  function up(ev) {
    btn.releasePointerCapture?.(ev.pointerId);

    document.removeEventListener("pointermove", move);
    document.removeEventListener("pointerup", up);

    const label = btn.dataset.label;
    const b = btn.getBoundingClientRect();

    const centerX =
      b.left - frameRect.left + b.width / 2;

    const centerY =
      b.top - frameRect.top + b.height / 2;

    const pct = pxToPct(centerX, centerY);

    touchLayout[label].xPct = pct.xPct;
    touchLayout[label].yPct = pct.yPct;
  }

  document.addEventListener("pointermove", move);
  document.addEventListener("pointerup", up);
}

function startResize(btn, e) {
  if (!previewFrame) return;

  btn.setPointerCapture?.(e.pointerId);

  const startX = e.clientX;
  const rect = btn.getBoundingClientRect();

  function move(ev) {
    const dx = ev.clientX - startX;
    const newSize = Math.max(40, Math.min(160, rect.width + dx));

    btn.style.width = `${newSize}px`;
    btn.style.height = `${newSize}px`;
    btn.style.fontSize = `${Math.max(14, newSize * 0.28)}px`;
  }

  function up(ev) {
    btn.releasePointerCapture?.(ev.pointerId);

    document.removeEventListener("pointermove", move);
    document.removeEventListener("pointerup", up);

    const label = btn.dataset.label;
    const size = parseInt(btn.style.width, 10);

    touchLayout[label].size = size;
    syncSliderToSelection();
  }

  document.addEventListener("pointermove", move);
  document.addEventListener("pointerup", up);
}

if (touchSizeSlider) {
  touchSizeSlider.addEventListener("input", () => {
    if (!selectedBtn) return;

    const label = selectedBtn.dataset.label;
    const size = parseInt(touchSizeSlider.value, 10);

    selectedBtn.style.width = `${size}px`;
    selectedBtn.style.height = `${size}px`;
    selectedBtn.style.fontSize = `${Math.max(14, size * 0.28)}px`;

    touchLayout[label].size = size;
  });
}

if (btnEditTouch) {
  btnEditTouch.addEventListener("click", () => {
    editingTouch = !editingTouch;

    btnEditTouch.textContent =
      editingTouch ? "Stop Editing" : "Edit Touch Layout";

    if (previewFrame) {
      previewFrame.style.outline =
        editingTouch ? "3px solid rgba(255,0,0,.65)" : "none";
    }
  });
}

if (btnSaveTouch) {
  btnSaveTouch.addEventListener("click", () => {
    saveTouchLayout();

    const oldText = btnSaveTouch.textContent;
    btnSaveTouch.textContent = "Saved!";

    setTimeout(() => {
      btnSaveTouch.textContent = oldText;
    }, 800);
  });
}

if (btnResetTouch) {
  btnResetTouch.addEventListener("click", () => {
    touchLayout = structuredCloneSafe(DEFAULT_TOUCH_LAYOUT);
    saveTouchLayout();
    renderTouchPreview();
  });
}

// ---------- Actual in-game mobile controls ----------
// The preview is NOT the live game control layer.
// This layer remains hidden until showTouchControls() is called.

function renderLiveTouchControls() {
  if (!liveTouchControls) return;

  liveTouchControls.innerHTML = "";

  Object.entries(touchLayout).forEach(([label, cfg]) => {
    const btn = document.createElement("button");

    btn.className = "game-touch-button";
    btn.dataset.action = cfg.action;
    btn.textContent = label;

    btn.style.left = `${cfg.xPct}%`;
    btn.style.top = `${cfg.yPct}%`;
    btn.style.width = `${cfg.size}px`;
    btn.style.height = `${cfg.size}px`;
    btn.style.transform = "translate(-50%, -50%)";
    btn.style.fontSize = `${Math.max(14, cfg.size * .28)}px`;

    btn.addEventListener("pointerdown", e => {
      e.preventDefault();
      handleTouchAction(cfg.action, true);
    });

    btn.addEventListener("pointerup", e => {
      e.preventDefault();
      handleTouchAction(cfg.action, false);
    });

    btn.addEventListener("pointercancel", e => {
      handleTouchAction(cfg.action, false);
    });

    liveTouchControls.appendChild(btn);
  });
}

function handleTouchAction(action, pressed) {
  // Game code can listen for this custom event.
  window.dispatchEvent(new CustomEvent("crzy-touch-input", {
    detail: { action, pressed }
  }));
}

function showTouchControls(show = true) {
  if (!liveTouchControls) return;

  if (show) {
    renderLiveTouchControls();
    liveTouchControls.style.display = "block";
  } else {
    liveTouchControls.style.display = "none";
  }
}

window.showTouchControls = showTouchControls;

window.hideTouchControls = function() {
  showTouchControls(false);
};

// ---------- Menu integration ----------

function onMenuSwitch(targetId) {
  const isControls = targetId === "controls-menu";

  showPreviewFrame(isControls);

  if (isControls) {
    renderBindingsList();
    updateControllerStatus();
  }
}

document.addEventListener("click", e => {
  const btn = e.target.closest(".menu-tab");
  if (!btn) return;

  const target = btn.dataset?.target;

  if (!target) return;

  requestAnimationFrame(() => {
    onMenuSwitch(target);
  });
});

// ---------- Resize handling ----------

window.addEventListener("resize", () => {
  if (previewFrame && previewFrame.style.display !== "none") {
    renderTouchPreview();
  }

  // Re-render live controls so percentage positioning remains responsive.
  if (liveTouchControls && liveTouchControls.style.display !== "none") {
    renderLiveTouchControls();
  }
});

// ---------- Initial state ----------

document.addEventListener("DOMContentLoaded", () => {
  renderBindingsList();
  updateControllerStatus();
  showPreviewFrame(false);

  // IMPORTANT:
  // Do not show mobile controls on menus.
  hideTouchControls();
});

// Make the binding functions available to the game if needed.
window.getControlBinding = function(action) {
  return bindings[action];
};

window.getAllControlBindings = function() {
  return structuredCloneSafe(bindings);
};

window.getTouchLayout = function() {
  return structuredCloneSafe(touchLayout);
};

window.saveControlSettings = function() {
  saveBindings();
  saveTouchLayout();
};
